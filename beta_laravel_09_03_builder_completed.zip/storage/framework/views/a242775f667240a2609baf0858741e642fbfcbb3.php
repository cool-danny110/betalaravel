<title>ACCOUNT : Settings</title>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="my_box">

    <div class="box_head row">

    <div class="col-md-6">
        <h1>Settings</h1>
        <!--
        <div class="item">
        <h1>Settings</h1>
        </div>
        <div class="item">
        <div class="top_link">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#db0505" class="bi bi-arrow-right-square-fill" viewBox="0 0 16 16">
            <path d="M0 14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2a2 2 0 0 0-2 2v12zm4.5-6.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5a.5.5 0 0 1 0-1z"/>
            </svg> &nbsp;<a href="#">Start Your New Campaign Now</a>
        </div>
        </div>
        -->
    </div>
    <div class="col-md-6 right pdt-5">
    <button class="my_but white">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" width="20" height="20" fill="currentColor"><!--! Font Awesome Pro 6.0.0 by @fontawesome  - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M77.25 256l137.4-137.4c12.5-12.5 12.5-32.75 0-45.25s-32.75-12.5-45.25 0l-160 160c-12.5 12.5-12.5 32.75 0 45.25l160 160C175.6 444.9 183.8 448 192 448s16.38-3.125 22.62-9.375c12.5-12.5 12.5-32.75 0-45.25L77.25 256zM269.3 256l137.4-137.4c12.5-12.5 12.5-32.75 0-45.25s-32.75-12.5-45.25 0l-160 160c-12.5 12.5-12.5 32.75 0 45.25l160 160C367.6 444.9 375.8 448 384 448s16.38-3.125 22.62-9.375c12.5-12.5 12.5-32.75 0-45.25L269.3 256z"/></svg></svg><span class="spacer-left-xxs">Go Back</span>
    </button>

    <button class="my_but2">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" width="20" height="20"><!--! Font Awesome Pro 6.0.0 by @fontawesome  - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M438.6 105.4C451.1 117.9 451.1 138.1 438.6 150.6L182.6 406.6C170.1 419.1 149.9 419.1 137.4 406.6L9.372 278.6C-3.124 266.1-3.124 245.9 9.372 233.4C21.87 220.9 42.13 220.9 54.63 233.4L159.1 338.7L393.4 105.4C405.9 92.88 426.1 92.88 438.6 105.4H438.6z"/></svg><span class="spacer-left-xxs">Save</span>
    </button>
    </div>
    </div>

    <div class="box_body" style="min-height:680px">



    <div class="row">

    <div class="content_box col-md-6">


    <div class="pane pane-default box-border-all">
    <div class="pane-top">
    <h4>General</h4>
    </div>

    <div class="pane-content row">
    <div class="form-group col-md-8">
    <label>Time zone</label>
    <select name="timezone" id="timezone" class="form-control">
    <option value="Pacific/Midway">(GMT-11:00) Midway</option><option value="Pacific/Niue">(GMT-11:00) Niue</option><option value="Pacific/Pago_Pago">(GMT-11:00) Pago Pago</option><option value="America/Adak">(GMT-10:00) Adak</option><option value="Pacific/Honolulu">(GMT-10:00) Honolulu</option><option value="Pacific/Rarotonga">(GMT-10:00) Rarotonga</option><option value="Pacific/Tahiti">(GMT-10:00) Tahiti</option><option value="Pacific/Marquesas">(GMT-09:30) Marquesas</option><option value="America/Anchorage">(GMT-09:00) Anchorage</option><option value="Pacific/Gambier">(GMT-09:00) Gambier</option><option value="America/Juneau">(GMT-09:00) Juneau</option><option value="America/Metlakatla">(GMT-09:00) Metlakatla</option><option value="America/Nome">(GMT-09:00) Nome</option><option value="America/Sitka">(GMT-09:00) Sitka</option><option value="America/Yakutat">(GMT-09:00) Yakutat</option><option value="America/Los_Angeles">(GMT-08:00) Los Angeles</option><option value="Pacific/Pitcairn">(GMT-08:00) Pitcairn</option><option value="America/Tijuana">(GMT-08:00) Tijuana</option><option value="America/Vancouver">(GMT-08:00) Vancouver</option><option value="America/Boise">(GMT-07:00) Boise</option><option value="America/Cambridge_Bay">(GMT-07:00) Cambridge Bay</option><option value="America/Chihuahua">(GMT-07:00) Chihuahua</option><option value="America/Creston">(GMT-07:00) Creston</option><option value="America/Dawson">(GMT-07:00) Dawson</option><option value="America/Dawson_Creek">(GMT-07:00) Dawson Creek</option><option value="America/Denver">(GMT-07:00) Denver</option><option value="America/Edmonton">(GMT-07:00) Edmonton</option><option value="America/Fort_Nelson">(GMT-07:00) Fort Nelson</option><option value="America/Hermosillo">(GMT-07:00) Hermosillo</option><option value="America/Inuvik">(GMT-07:00) Inuvik</option><option value="America/Mazatlan">(GMT-07:00) Mazatlan</option><option value="America/Ojinaga">(GMT-07:00) Ojinaga</option><option value="America/Phoenix">(GMT-07:00) Phoenix</option><option value="America/Whitehorse">(GMT-07:00) Whitehorse</option><option value="America/Yellowknife">(GMT-07:00) Yellowknife</option><option value="America/Bahia_Banderas">(GMT-06:00) Bahia Banderas</option><option value="America/Belize">(GMT-06:00) Belize</option><option value="America/North_Dakota/Beulah">(GMT-06:00) Beulah</option><option value="America/North_Dakota/Center">(GMT-06:00) Center</option><option value="America/Chicago">(GMT-06:00) Chicago</option><option value="America/Costa_Rica">(GMT-06:00) Costa Rica</option><option value="America/El_Salvador">(GMT-06:00) El Salvador</option><option value="Pacific/Galapagos">(GMT-06:00) Galapagos</option><option value="America/Guatemala">(GMT-06:00) Guatemala</option><option value="America/Indiana/Knox">(GMT-06:00) Knox</option><option value="America/Managua">(GMT-06:00) Managua</option><option value="America/Matamoros">(GMT-06:00) Matamoros</option><option value="America/Menominee">(GMT-06:00) Menominee</option><option value="America/Merida">(GMT-06:00) Merida</option><option value="America/Mexico_City">(GMT-06:00) Mexico City</option><option value="America/Monterrey">(GMT-06:00) Monterrey</option><option value="America/North_Dakota/New_Salem">(GMT-06:00) New Salem</option><option value="America/Rainy_River">(GMT-06:00) Rainy River</option><option value="America/Rankin_Inlet">(GMT-06:00) Rankin Inlet</option><option value="America/Regina">(GMT-06:00) Regina</option><option value="America/Resolute">(GMT-06:00) Resolute</option><option value="America/Swift_Current">(GMT-06:00) Swift Current</option><option value="America/Tegucigalpa">(GMT-06:00) Tegucigalpa</option><option value="America/Indiana/Tell_City">(GMT-06:00) Tell City</option><option value="America/Winnipeg">(GMT-06:00) Winnipeg</option><option value="America/Atikokan">(GMT-05:00) Atikokan</option><option value="America/Bogota">(GMT-05:00) Bogota</option><option value="America/Cancun">(GMT-05:00) Cancun</option><option value="America/Cayman">(GMT-05:00) Cayman</option><option value="America/Detroit">(GMT-05:00) Detroit</option><option value="Pacific/Easter">(GMT-05:00) Easter</option><option value="America/Eirunepe">(GMT-05:00) Eirunepe</option><option value="America/Grand_Turk">(GMT-05:00) Grand Turk</option><option value="America/Guayaquil">(GMT-05:00) Guayaquil</option><option value="America/Havana">(GMT-05:00) Havana</option><option value="America/Indiana/Indianapolis">(GMT-05:00) Indianapolis</option><option value="America/Iqaluit">(GMT-05:00) Iqaluit</option><option value="America/Jamaica">(GMT-05:00) Jamaica</option><option value="America/Lima">(GMT-05:00) Lima</option><option value="America/Kentucky/Louisville">(GMT-05:00) Louisville</option><option value="America/Indiana/Marengo">(GMT-05:00) Marengo</option><option value="America/Kentucky/Monticello">(GMT-05:00) Monticello</option><option value="America/Nassau">(GMT-05:00) Nassau</option><option value="America/New_York">(GMT-05:00) New York</option><option value="America/Nipigon">(GMT-05:00) Nipigon</option><option value="America/Panama">(GMT-05:00) Panama</option><option value="America/Pangnirtung">(GMT-05:00) Pangnirtung</option><option value="America/Indiana/Petersburg">(GMT-05:00) Petersburg</option><option value="America/Port-au-Prince">(GMT-05:00) Port-au-Prince</option><option value="America/Rio_Branco">(GMT-05:00) Rio Branco</option><option value="America/Thunder_Bay">(GMT-05:00) Thunder Bay</option><option value="America/Toronto">(GMT-05:00) Toronto</option><option value="America/Indiana/Vevay">(GMT-05:00) Vevay</option><option value="America/Indiana/Vincennes">(GMT-05:00) Vincennes</option><option value="America/Indiana/Winamac">(GMT-05:00) Winamac</option><option value="America/Anguilla">(GMT-04:00) Anguilla</option><option value="America/Antigua">(GMT-04:00) Antigua</option><option value="America/Aruba">(GMT-04:00) Aruba</option><option value="America/Barbados">(GMT-04:00) Barbados</option><option value="Atlantic/Bermuda">(GMT-04:00) Bermuda</option><option value="America/Blanc-Sablon">(GMT-04:00) Blanc-Sablon</option><option value="America/Boa_Vista">(GMT-04:00) Boa Vista</option><option value="America/Campo_Grande">(GMT-04:00) Campo Grande</option><option value="America/Caracas">(GMT-04:00) Caracas</option><option value="America/Cuiaba">(GMT-04:00) Cuiaba</option><option value="America/Curacao">(GMT-04:00) Curacao</option><option value="America/Dominica">(GMT-04:00) Dominica</option><option value="America/Glace_Bay">(GMT-04:00) Glace Bay</option><option value="America/Goose_Bay">(GMT-04:00) Goose Bay</option><option value="America/Grenada">(GMT-04:00) Grenada</option><option value="America/Guadeloupe">(GMT-04:00) Guadeloupe</option><option value="America/Guyana">(GMT-04:00) Guyana</option><option value="America/Halifax">(GMT-04:00) Halifax</option><option value="America/Kralendijk">(GMT-04:00) Kralendijk</option><option value="America/La_Paz">(GMT-04:00) La Paz</option><option value="America/Lower_Princes">(GMT-04:00) Lower Princes</option><option value="America/Manaus">(GMT-04:00) Manaus</option><option value="America/Marigot">(GMT-04:00) Marigot</option><option value="America/Martinique">(GMT-04:00) Martinique</option><option value="America/Moncton">(GMT-04:00) Moncton</option><option value="America/Montserrat">(GMT-04:00) Montserrat</option><option value="America/Port_of_Spain">(GMT-04:00) Port of Spain</option><option value="America/Porto_Velho">(GMT-04:00) Porto Velho</option><option value="America/Puerto_Rico">(GMT-04:00) Puerto Rico</option><option value="America/Santo_Domingo">(GMT-04:00) Santo Domingo</option><option value="America/St_Barthelemy">(GMT-04:00) St Barthelemy</option><option value="America/St_Kitts">(GMT-04:00) St Kitts</option><option value="America/St_Lucia">(GMT-04:00) St Lucia</option><option value="America/St_Thomas">(GMT-04:00) St Thomas</option><option value="America/St_Vincent">(GMT-04:00) St Vincent</option><option value="America/Thule">(GMT-04:00) Thule</option><option value="America/Tortola">(GMT-04:00) Tortola</option><option value="America/St_Johns">(GMT-03:30) St Johns</option><option value="America/Araguaina">(GMT-03:00) Araguaina</option><option value="America/Asuncion">(GMT-03:00) Asuncion</option><option value="America/Bahia">(GMT-03:00) Bahia</option><option value="America/Belem">(GMT-03:00) Belem</option><option value="America/Argentina/Buenos_Aires">(GMT-03:00) Buenos Aires</option><option value="America/Argentina/Catamarca">(GMT-03:00) Catamarca</option><option value="America/Cayenne">(GMT-03:00) Cayenne</option><option value="America/Argentina/Cordoba">(GMT-03:00) Cordoba</option><option value="America/Fortaleza">(GMT-03:00) Fortaleza</option><option value="America/Argentina/Jujuy">(GMT-03:00) Jujuy</option><option value="America/Argentina/La_Rioja">(GMT-03:00) La Rioja</option><option value="America/Maceio">(GMT-03:00) Maceio</option><option value="America/Argentina/Mendoza">(GMT-03:00) Mendoza</option><option value="America/Miquelon">(GMT-03:00) Miquelon</option><option value="America/Montevideo">(GMT-03:00) Montevideo</option><option value="America/Nuuk">(GMT-03:00) Nuuk</option><option value="Antarctica/Palmer">(GMT-03:00) Palmer</option><option value="America/Paramaribo">(GMT-03:00) Paramaribo</option><option value="America/Punta_Arenas">(GMT-03:00) Punta Arenas</option><option value="America/Recife">(GMT-03:00) Recife</option><option value="America/Argentina/Rio_Gallegos">(GMT-03:00) Rio Gallegos</option><option value="Antarctica/Rothera">(GMT-03:00) Rothera</option><option value="America/Argentina/Salta">(GMT-03:00) Salta</option><option value="America/Argentina/San_Juan">(GMT-03:00) San Juan</option><option value="America/Argentina/San_Luis">(GMT-03:00) San Luis</option><option value="America/Santarem">(GMT-03:00) Santarem</option><option value="America/Santiago">(GMT-03:00) Santiago</option><option value="America/Sao_Paulo">(GMT-03:00) Sao Paulo</option><option value="Atlantic/Stanley">(GMT-03:00) Stanley</option><option value="America/Argentina/Tucuman">(GMT-03:00) Tucuman</option><option value="America/Argentina/Ushuaia">(GMT-03:00) Ushuaia</option><option value="America/Noronha">(GMT-02:00) Noronha</option><option value="Atlantic/South_Georgia">(GMT-02:00) South Georgia</option><option value="Atlantic/Azores">(GMT-01:00) Azores</option><option value="Atlantic/Cape_Verde">(GMT-01:00) Cape Verde</option><option value="America/Scoresbysund">(GMT-01:00) Scoresbysund</option><option value="Africa/Abidjan">(GMT+00:00) Abidjan</option><option value="Africa/Accra">(GMT+00:00) Accra</option><option value="Africa/Bamako">(GMT+00:00) Bamako</option><option value="Africa/Banjul">(GMT+00:00) Banjul</option><option value="Africa/Bissau">(GMT+00:00) Bissau</option><option value="Atlantic/Canary">(GMT+00:00) Canary</option><option value="Africa/Conakry">(GMT+00:00) Conakry</option><option value="Africa/Dakar">(GMT+00:00) Dakar</option><option value="America/Danmarkshavn">(GMT+00:00) Danmarkshavn</option><option value="Europe/Dublin">(GMT+00:00) Dublin</option><option value="Atlantic/Faroe">(GMT+00:00) Faroe</option><option value="Africa/Freetown">(GMT+00:00) Freetown</option><option value="Europe/Guernsey">(GMT+00:00) Guernsey</option><option value="Europe/Isle_of_Man">(GMT+00:00) Isle of Man</option><option value="Europe/Jersey">(GMT+00:00) Jersey</option><option value="Europe/Lisbon">(GMT+00:00) Lisbon</option><option value="Africa/Lome">(GMT+00:00) Lome</option><option value="Europe/London">(GMT+00:00) London</option><option value="Atlantic/Madeira">(GMT+00:00) Madeira</option><option value="Africa/Monrovia">(GMT+00:00) Monrovia</option><option value="Africa/Nouakchott">(GMT+00:00) Nouakchott</option><option value="Africa/Ouagadougou">(GMT+00:00) Ouagadougou</option><option value="Atlantic/Reykjavik">(GMT+00:00) Reykjavik</option><option value="Africa/Sao_Tome">(GMT+00:00) Sao Tome</option><option value="Atlantic/St_Helena">(GMT+00:00) St Helena</option><option value="Antarctica/Troll">(GMT+00:00) Troll</option><option value="Africa/Algiers">(GMT+01:00) Algiers</option><option value="Europe/Amsterdam">(GMT+01:00) Amsterdam</option><option value="Europe/Andorra">(GMT+01:00) Andorra</option><option value="Africa/Bangui">(GMT+01:00) Bangui</option><option value="Europe/Belgrade">(GMT+01:00) Belgrade</option><option value="Europe/Berlin">(GMT+01:00) Berlin</option><option value="Europe/Bratislava">(GMT+01:00) Bratislava</option><option value="Africa/Brazzaville">(GMT+01:00) Brazzaville</option><option value="Europe/Brussels">(GMT+01:00) Brussels</option><option value="Europe/Budapest">(GMT+01:00) Budapest</option><option value="Europe/Busingen">(GMT+01:00) Busingen</option><option value="Africa/Casablanca">(GMT+01:00) Casablanca</option><option value="Africa/Ceuta">(GMT+01:00) Ceuta</option><option value="Europe/Copenhagen">(GMT+01:00) Copenhagen</option><option value="Africa/Douala">(GMT+01:00) Douala</option><option value="Africa/El_Aaiun">(GMT+01:00) El Aaiun</option><option value="Europe/Gibraltar">(GMT+01:00) Gibraltar</option><option value="Africa/Kinshasa">(GMT+01:00) Kinshasa</option><option value="Africa/Lagos">(GMT+01:00) Lagos</option><option value="Africa/Libreville">(GMT+01:00) Libreville</option><option value="Europe/Ljubljana">(GMT+01:00) Ljubljana</option><option value="Arctic/Longyearbyen">(GMT+01:00) Longyearbyen</option><option value="Africa/Luanda">(GMT+01:00) Luanda</option><option value="Europe/Luxembourg">(GMT+01:00) Luxembourg</option><option value="Europe/Madrid">(GMT+01:00) Madrid</option><option value="Africa/Malabo">(GMT+01:00) Malabo</option><option value="Europe/Malta">(GMT+01:00) Malta</option><option value="Europe/Monaco">(GMT+01:00) Monaco</option><option value="Africa/Ndjamena">(GMT+01:00) Ndjamena</option><option value="Africa/Niamey">(GMT+01:00) Niamey</option><option value="Europe/Oslo">(GMT+01:00) Oslo</option><option value="Europe/Paris">(GMT+01:00) Paris</option><option value="Europe/Podgorica">(GMT+01:00) Podgorica</option><option value="Africa/Porto-Novo">(GMT+01:00) Porto-Novo</option><option value="Europe/Prague">(GMT+01:00) Prague</option><option value="Europe/Rome">(GMT+01:00) Rome</option><option value="Europe/San_Marino">(GMT+01:00) San Marino</option><option value="Europe/Sarajevo">(GMT+01:00) Sarajevo</option><option value="Europe/Skopje">(GMT+01:00) Skopje</option><option value="Europe/Stockholm">(GMT+01:00) Stockholm</option><option value="Europe/Tirane">(GMT+01:00) Tirane</option><option value="Africa/Tunis">(GMT+01:00) Tunis</option><option value="Europe/Vaduz">(GMT+01:00) Vaduz</option><option value="Europe/Vatican">(GMT+01:00) Vatican</option><option value="Europe/Vienna">(GMT+01:00) Vienna</option><option value="Europe/Warsaw">(GMT+01:00) Warsaw</option><option value="Europe/Zagreb">(GMT+01:00) Zagreb</option><option value="Europe/Zurich">(GMT+01:00) Zurich</option><option value="Asia/Amman">(GMT+02:00) Amman</option><option value="Europe/Athens">(GMT+02:00) Athens</option><option value="Asia/Beirut">(GMT+02:00) Beirut</option><option value="Africa/Blantyre">(GMT+02:00) Blantyre</option><option value="Europe/Bucharest">(GMT+02:00) Bucharest</option><option value="Africa/Bujumbura">(GMT+02:00) Bujumbura</option><option value="Africa/Cairo">(GMT+02:00) Cairo</option><option value="Europe/Chisinau">(GMT+02:00) Chisinau</option><option value="Asia/Damascus">(GMT+02:00) Damascus</option><option value="Asia/Famagusta">(GMT+02:00) Famagusta</option><option value="Africa/Gaborone">(GMT+02:00) Gaborone</option><option value="Asia/Gaza">(GMT+02:00) Gaza</option><option value="Africa/Harare">(GMT+02:00) Harare</option><option value="Asia/Hebron">(GMT+02:00) Hebron</option><option value="Europe/Helsinki">(GMT+02:00) Helsinki</option><option value="Asia/Jerusalem">(GMT+02:00) Jerusalem</option><option value="Africa/Johannesburg">(GMT+02:00) Johannesburg</option><option value="Africa/Juba">(GMT+02:00) Juba</option><option value="Europe/Kaliningrad">(GMT+02:00) Kaliningrad</option><option value="Africa/Khartoum">(GMT+02:00) Khartoum</option><option value="Europe/Kiev">(GMT+02:00) Kiev</option><option value="Africa/Kigali">(GMT+02:00) Kigali</option><option value="Africa/Lubumbashi">(GMT+02:00) Lubumbashi</option><option value="Africa/Lusaka">(GMT+02:00) Lusaka</option><option value="Africa/Maputo">(GMT+02:00) Maputo</option><option value="Europe/Mariehamn">(GMT+02:00) Mariehamn</option><option value="Africa/Maseru">(GMT+02:00) Maseru</option><option value="Africa/Mbabane">(GMT+02:00) Mbabane</option><option value="Asia/Nicosia">(GMT+02:00) Nicosia</option><option value="Europe/Riga">(GMT+02:00) Riga</option><option value="Europe/Sofia">(GMT+02:00) Sofia</option><option value="Europe/Tallinn">(GMT+02:00) Tallinn</option><option value="Africa/Tripoli">(GMT+02:00) Tripoli</option><option value="Europe/Uzhgorod">(GMT+02:00) Uzhgorod</option><option value="Europe/Vilnius">(GMT+02:00) Vilnius</option><option value="Africa/Windhoek">(GMT+02:00) Windhoek</option><option value="Europe/Zaporozhye">(GMT+02:00) Zaporozhye</option><option value="Africa/Addis_Ababa">(GMT+03:00) Addis Ababa</option><option value="Asia/Aden">(GMT+03:00) Aden</option><option value="Indian/Antananarivo">(GMT+03:00) Antananarivo</option><option value="Africa/Asmara">(GMT+03:00) Asmara</option><option value="Asia/Baghdad">(GMT+03:00) Baghdad</option><option value="Asia/Bahrain">(GMT+03:00) Bahrain</option><option value="Indian/Comoro">(GMT+03:00) Comoro</option><option value="Africa/Dar_es_Salaam">(GMT+03:00) Dar es Salaam</option><option value="Africa/Djibouti">(GMT+03:00) Djibouti</option><option value="Europe/Istanbul">(GMT+03:00) Istanbul</option><option value="Africa/Kampala">(GMT+03:00) Kampala</option><option value="Europe/Kirov">(GMT+03:00) Kirov</option><option value="Asia/Kuwait">(GMT+03:00) Kuwait</option><option value="Indian/Mayotte">(GMT+03:00) Mayotte</option><option value="Europe/Minsk">(GMT+03:00) Minsk</option><option value="Africa/Mogadishu">(GMT+03:00) Mogadishu</option><option value="Europe/Moscow">(GMT+03:00) Moscow</option><option value="Africa/Nairobi">(GMT+03:00) Nairobi</option><option value="Asia/Qatar">(GMT+03:00) Qatar</option><option value="Asia/Riyadh">(GMT+03:00) Riyadh</option><option value="Europe/Simferopol">(GMT+03:00) Simferopol</option><option value="Antarctica/Syowa">(GMT+03:00) Syowa</option><option value="Europe/Volgograd">(GMT+03:00) Volgograd</option><option value="Asia/Tehran">(GMT+03:30) Tehran</option><option value="Europe/Astrakhan">(GMT+04:00) Astrakhan</option><option value="Asia/Baku">(GMT+04:00) Baku</option><option value="Asia/Dubai">(GMT+04:00) Dubai</option><option value="Indian/Mahe">(GMT+04:00) Mahe</option><option value="Indian/Mauritius">(GMT+04:00) Mauritius</option><option value="Asia/Muscat">(GMT+04:00) Muscat</option><option value="Indian/Reunion">(GMT+04:00) Reunion</option><option value="Europe/Samara">(GMT+04:00) Samara</option><option value="Europe/Saratov">(GMT+04:00) Saratov</option><option value="Asia/Tbilisi">(GMT+04:00) Tbilisi</option><option value="Europe/Ulyanovsk">(GMT+04:00) Ulyanovsk</option><option value="Asia/Yerevan">(GMT+04:00) Yerevan</option><option value="Asia/Kabul">(GMT+04:30) Kabul</option><option value="Asia/Aqtau">(GMT+05:00) Aqtau</option><option value="Asia/Aqtobe">(GMT+05:00) Aqtobe</option><option value="Asia/Ashgabat">(GMT+05:00) Ashgabat</option><option value="Asia/Atyrau">(GMT+05:00) Atyrau</option><option value="Asia/Dushanbe">(GMT+05:00) Dushanbe</option><option value="Asia/Karachi">(GMT+05:00) Karachi</option><option value="Indian/Kerguelen">(GMT+05:00) Kerguelen</option><option value="Indian/Maldives">(GMT+05:00) Maldives</option><option value="Antarctica/Mawson">(GMT+05:00) Mawson</option><option value="Asia/Oral">(GMT+05:00) Oral</option><option value="Asia/Qyzylorda">(GMT+05:00) Qyzylorda</option><option value="Asia/Samarkand">(GMT+05:00) Samarkand</option><option value="Asia/Tashkent">(GMT+05:00) Tashkent</option><option value="Asia/Yekaterinburg">(GMT+05:00) Yekaterinburg</option><option value="Asia/Colombo">(GMT+05:30) Colombo</option><option value="Asia/Kolkata">(GMT+05:30) Kolkata</option><option value="Asia/Kathmandu">(GMT+05:45) Kathmandu</option><option value="Asia/Almaty">(GMT+06:00) Almaty</option><option value="Asia/Bishkek">(GMT+06:00) Bishkek</option><option value="Indian/Chagos">(GMT+06:00) Chagos</option><option value="Asia/Dhaka">(GMT+06:00) Dhaka</option><option value="Asia/Omsk">(GMT+06:00) Omsk</option><option value="Asia/Qostanay">(GMT+06:00) Qostanay</option><option value="Asia/Thimphu">(GMT+06:00) Thimphu</option><option value="Asia/Urumqi">(GMT+06:00) Urumqi</option><option value="Antarctica/Vostok">(GMT+06:00) Vostok</option><option value="Indian/Cocos">(GMT+06:30) Cocos</option><option value="Asia/Yangon">(GMT+06:30) Yangon</option><option value="Asia/Bangkok">(GMT+07:00) Bangkok</option><option value="Asia/Barnaul">(GMT+07:00) Barnaul</option><option value="Indian/Christmas">(GMT+07:00) Christmas</option><option value="Antarctica/Davis">(GMT+07:00) Davis</option><option value="Asia/Ho_Chi_Minh">(GMT+07:00) Ho Chi Minh</option><option value="Asia/Hovd">(GMT+07:00) Hovd</option><option value="Asia/Jakarta">(GMT+07:00) Jakarta</option><option value="Asia/Krasnoyarsk">(GMT+07:00) Krasnoyarsk</option><option value="Asia/Novokuznetsk">(GMT+07:00) Novokuznetsk</option><option value="Asia/Novosibirsk">(GMT+07:00) Novosibirsk</option><option value="Asia/Phnom_Penh">(GMT+07:00) Phnom Penh</option><option value="Asia/Pontianak">(GMT+07:00) Pontianak</option><option value="Asia/Tomsk">(GMT+07:00) Tomsk</option><option value="Asia/Vientiane">(GMT+07:00) Vientiane</option><option value="Asia/Brunei">(GMT+08:00) Brunei</option><option value="Asia/Choibalsan">(GMT+08:00) Choibalsan</option><option value="Asia/Hong_Kong">(GMT+08:00) Hong Kong</option><option value="Asia/Irkutsk">(GMT+08:00) Irkutsk</option><option value="Asia/Kuala_Lumpur">(GMT+08:00) Kuala Lumpur</option><option value="Asia/Kuching">(GMT+08:00) Kuching</option><option value="Asia/Macau">(GMT+08:00) Macau</option><option value="Asia/Makassar">(GMT+08:00) Makassar</option><option value="Asia/Manila">(GMT+08:00) Manila</option><option value="Australia/Perth">(GMT+08:00) Perth</option><option value="Asia/Shanghai">(GMT+08:00) Shanghai</option><option value="Asia/Singapore">(GMT+08:00) Singapore</option><option value="Asia/Taipei">(GMT+08:00) Taipei</option><option value="Asia/Ulaanbaatar">(GMT+08:00) Ulaanbaatar</option><option value="Australia/Eucla">(GMT+08:45) Eucla</option><option value="Asia/Chita">(GMT+09:00) Chita</option><option value="Asia/Dili">(GMT+09:00) Dili</option><option value="Asia/Jayapura">(GMT+09:00) Jayapura</option><option value="Asia/Khandyga">(GMT+09:00) Khandyga</option><option value="Pacific/Palau">(GMT+09:00) Palau</option><option value="Asia/Pyongyang">(GMT+09:00) Pyongyang</option><option value="Asia/Seoul">(GMT+09:00) Seoul</option><option value="Asia/Tokyo">(GMT+09:00) Tokyo</option><option value="Asia/Yakutsk">(GMT+09:00) Yakutsk</option><option value="Australia/Darwin">(GMT+09:30) Darwin</option><option value="Australia/Brisbane">(GMT+10:00) Brisbane</option><option value="Pacific/Chuuk">(GMT+10:00) Chuuk</option><option value="Antarctica/DumontDUrville">(GMT+10:00) DumontDUrville</option><option value="Pacific/Guam">(GMT+10:00) Guam</option><option value="Australia/Lindeman">(GMT+10:00) Lindeman</option><option value="Pacific/Port_Moresby">(GMT+10:00) Port Moresby</option><option value="Pacific/Saipan">(GMT+10:00) Saipan</option><option value="Asia/Ust-Nera">(GMT+10:00) Ust-Nera</option><option value="Asia/Vladivostok">(GMT+10:00) Vladivostok</option><option value="Australia/Adelaide">(GMT+10:30) Adelaide</option><option value="Australia/Broken_Hill">(GMT+10:30) Broken Hill</option><option value="Pacific/Bougainville">(GMT+11:00) Bougainville</option><option value="Antarctica/Casey">(GMT+11:00) Casey</option><option value="Pacific/Efate">(GMT+11:00) Efate</option><option value="Pacific/Guadalcanal">(GMT+11:00) Guadalcanal</option><option value="Australia/Hobart">(GMT+11:00) Hobart</option><option value="Pacific/Kosrae">(GMT+11:00) Kosrae</option><option value="Australia/Lord_Howe">(GMT+11:00) Lord Howe</option><option value="Antarctica/Macquarie">(GMT+11:00) Macquarie</option><option value="Asia/Magadan">(GMT+11:00) Magadan</option><option value="Australia/Melbourne">(GMT+11:00) Melbourne</option><option value="Pacific/Noumea">(GMT+11:00) Noumea</option><option value="Pacific/Pohnpei">(GMT+11:00) Pohnpei</option><option value="Asia/Sakhalin">(GMT+11:00) Sakhalin</option><option value="Asia/Srednekolymsk">(GMT+11:00) Srednekolymsk</option><option value="Australia/Sydney">(GMT+11:00) Sydney</option><option value="Asia/Anadyr">(GMT+12:00) Anadyr</option><option value="Pacific/Fiji">(GMT+12:00) Fiji</option><option value="Pacific/Funafuti">(GMT+12:00) Funafuti</option><option value="Asia/Kamchatka">(GMT+12:00) Kamchatka</option><option value="Pacific/Kwajalein">(GMT+12:00) Kwajalein</option><option value="Pacific/Majuro">(GMT+12:00) Majuro</option><option value="Pacific/Nauru">(GMT+12:00) Nauru</option><option value="Pacific/Norfolk">(GMT+12:00) Norfolk</option><option value="Pacific/Tarawa">(GMT+12:00) Tarawa</option><option value="Pacific/Wake">(GMT+12:00) Wake</option><option value="Pacific/Wallis">(GMT+12:00) Wallis</option><option value="Pacific/Auckland">(GMT+13:00) Auckland</option><option value="Pacific/Enderbury">(GMT+13:00) Enderbury</option><option value="Pacific/Fakaofo">(GMT+13:00) Fakaofo</option><option value="Antarctica/McMurdo">(GMT+13:00) McMurdo</option><option value="Pacific/Tongatapu">(GMT+13:00) Tongatapu</option><option value="Pacific/Chatham">(GMT+13:45) Chatham</option><option value="Pacific/Apia">(GMT+14:00) Apia</option><option value="Pacific/Kiritimati">(GMT+14:00) Kiritimati</option> </select>
    </div>
    <div class="form-group col-md-8 mt-15">
    <label>Delay Time</label>
    <a class="text-muted" href="javascript:void(0);"><i title="" data-original-title="" data-container="body" data-toggle="popover" data-placement="right" data-trigger="click" data-content="The Delay Time setting is for experts who send several email campaigns per week.  <br><br>To ensure contacts <b>do not receive multiple emails from you during a certain timeframe</b>, define this timeframe in the Delay Time field. (Enter this value as a <b>number of hours.</b>)<br><br>Your campaigns will be automatically re-programmed (delayed by 4 hours) for contacts who have already received an email from you in your custom 'Delay Time' timeframe." data-html="true" class="fa fa-question-circle"></i></a>
    <input type="text" name="" class="form-control delaytime" id="delay-time" value="0">
    </div>
    <div class="form-group col-md-12 mt-15">
    <label>Time Format</label>
    <div class="radio no-margin">
    <label class="radio-inline mr-15">
    <input type="radio" name="time_format" value="24" id="24hours" checked="checked">
    24 Hours </label>
    <label class="radio-inline">
    <input type="radio" name="time_format" value="12" id="12hours">
    12 Hours </label>
    </div>
    </div> 
    <div class="form-group col-md-12 mt-15">
    <label>Date Format</label>
    <div class="radio no-margin">
    <label class="radio-inline mr-15">
    <input type="radio" name="date_format" value="dd-mm-yyyy" id="dmy" checked="checked">
    DD-MM-YYYY  </label>
    <label class="radio-inline">
    <input type="radio" name="date_format" value="mm-dd-yyyy" id="mdy">
    MM-DD-YYYY </label>
    </div>
    </div>
    </div>

    </div>
    <div class="pane pane-default box-border-all">
    <div class="pane-top">
    <h4>Tracking</h4>
    </div>

    <div class="pane-content row">
    <div class="form-group col-md-12">
    <label>Hide Images URL</label>
    <a class="text-muted" href="javascript:void(0);"><i title="" data-original-title="" data-container="body" data-toggle="popover" data-placement="right" data-trigger="click" data-content="Selecting this option will <b>replace your image links with links hosted by SendinBlue.</b><br><br>  In some cases, enabling this option may improve the deliverability of your campaigns." data-html="true" class="fa fa-question-circle"></i></a>
    <div class="radio no-margin">
    <label class="radio-inline mr-15">
    <input type="radio" name="obfuscateurl" value="1" id="obfuscateurl" checked="checked">
    Yes </label>
    <label class="radio-inline">
    <input type="radio" name="obfuscateurl" value="0" id="obfuscateurl">
    No </label>
    </div>
    </div>
    </div>

    </div>
    <div class="pane pane-default box-border-all">
    <div class="pane-top">
    <h4>SMS Replies</h4>
    </div>

    <div class="pane-content row">
    <div class="form-group col-md-12">
    <label>Do you want to receive replies to your SMS campaigns by email?</label>
    <a class="text-muted" href="javascript:void(0);"><i title="" data-original-title="" data-container="body" data-toggle="popover" data-placement="right" data-trigger="click" data-content="If you send SMS messages to contacts in France, USA, UK, Canada, Sweden, Norway, French Polynesia, you may receive their replies via email. Enable this setting to receive them on your default login email address." data-html="true" class="fa fa-question-circle"></i></a>
    <div class="radio no-margin">
    <label class="radio-inline mr-15">
    <input type="radio" name="camp_sms_reply" value="1" id="camp_sms_reply">
    Yes </label>
    <label class="radio-inline">
    <input type="radio" name="camp_sms_reply" value="0" id="camp_sms_reply" checked="checked">
    No </label>
    </div>
    </div>
    </div>


    </div>
    <div class="pane pane-default box-border-all">
    <label>Do you want to disable SendinBlue activity notifications?</label>
    <a class="text-muted" href="javascript:void(0);"><i title="" data-original-title="" data-container="body" data-toggle="popover" data-placement="right" data-trigger="click" data-content="If you select 'yes', you will not receive email notifications based on activity in your SendinBlue account (such as importing/exporting contacts, deleting contact lists, campaigns sent, etc.)." data-html="true" class="fa fa-question-circle"></i></a>
    <div class="radio no-margin">
    <label class="radio-inline mr-15">
    <input type="radio" name="disable_notification_email" value="1">
    Yes </label>
    <label class="radio-inline">
    <input type="radio" name="disable_notification_email" value="0" checked="checked">
    No </label>
    </div>
    </div>


    </div>












    <div class="content_box col-md-6">

        <div class="pane pane-default box-border-all" id="camp-setting">
    <div class="pane-top">
    <h4>Default campaign settings</h4>
    </div>
    <div class="pane-content">
    <div class="form-group">
    <label>[DEFAULT_FROM_NAME]</label>
    <a class="text-muted" href="javascript:void(0);"><i title="" data-original-title="" data-container="body" data-toggle="popover" data-placement="right" data-trigger="click" data-content="The <b>sender's name</b> appears in your recipient's inbox to identify the sender. <br><br>  Its purpose is to build trust with recipients and generate more openings. <br><br> The sender name may be modified for individual campaigns during Step 1 of the campaign creation process." data-html="true" class="fa fa-question-circle"></i></a>
    <input type="text" name="" class="form-control defaultname" value="" id="default-from-name-input">
    </div>
    <div class="form-group mt-15">
    <label>[DEFAULT_FROM_EMAIL]</label>
    <a class="text-muted" href="javascript:void(0);"><i title="" data-original-title="" data-container="body" data-toggle="popover" data-placement="right" data-trigger="click" data-content="The <b>sender's email address</b> is associated with your messages and allows recipients to recognize you. <br> <br> Do not use an ISP domain address (@Gmail.com, @Yahoo.com, @Hotmail, @Aol.com, @Comcast.com, etc.) as your sender email address to ensure optimal deliverability for your campaigns.  <br><br>This value may be modified for individual campaigns during Step 1 of the campaign creation process." data-html="true" class="fa fa-question-circle"></i></a>
    <input type="text" name="" class="form-control emailfrom" value="peter@msbx.co.uk" id="default-from-email-input">
    </div>
    <div class="form-group mt-15">
    <label>[DEFAULT_HEADER]</label>
    <a class="text-muted" href="javascript:void(0);"><i title="" data-original-title="" data-container="body" data-toggle="popover" data-placement="right" data-trigger="click" data-content="<b>The email header</b> usually contains a 'mirror link'. This link allows recipients to read the email content on a web page. <br> <br> You may edit the header; text placed within braces will be the clickable link text. <i class='text-muted'>Ex: To read this newsletter in HTML format, click {here}.</i> <br> <br> This value may be modified for individual campaigns during Step 1 of the campaign creation process." data-html="true" class="fa fa-question-circle"></i></a>
    <textarea rows="" class="form-control headerarea" cols="" name=""></textarea>
    </div>
    <div class="form-group mt-15">
    <label>[DEFAULT_FOOTER]</label>
    <a class="text-muted" href="javascript:void(0);"><i title="" data-original-title="" data-container="body" data-toggle="popover" data-placement="right" data-trigger="click" data-content="The <b>email footer</b> <u>must</u> contain an unsubscribe link. <br><br>This allows your contacts to unsubscribe from your mailing lists. <br><br>You may edit the footer; text placed within braces will be the clickable link text.  <i class='text-muted'>Ex: Please click {here} to unsubscribe from our emails.</i> <br><br>This value may be modified for individual campaigns during Step 1 of the campaign creation process." data-html="true" class="fa fa-question-circle"></i></a>
    <textarea rows="" class="form-control footerarea" cols="" name=""></textarea>
    </div>
    <div class="form-group mt-15">
    <label>[DEFAULT_REPLY_TO]</label>
    <a class="text-muted" href="javascript:void(0);"><i title="" data-original-title="" data-container="body" data-toggle="popover" data-placement="right" data-trigger="click" data-content="This is the default email address your recipients will use when replying to your emails. <br><br>We suggest using an email address that you check regularly and avoid no-reply addresses. This creates a friendly, positive experience for your contacts. <br><br>This value may be modified for individual campaigns during Step 1 of the campaign creation process." data-html="true" class="fa fa-question-circle"></i></a>
    <input type="text" name="" class="form-control replyto" value="peter@msbx.co.uk" id="default-reply-to-input">
    </div>
    </div>
    </div>


    </div>









    </div>


    </div>









    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\beta_laravel\resources\views/setting.blade.php ENDPATH**/ ?>