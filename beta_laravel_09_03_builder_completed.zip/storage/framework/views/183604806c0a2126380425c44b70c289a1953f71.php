<title>ACCOUNT : Campaigns</title>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="my_box">
        <div class="box_head">
            <div class="item">
            <h1>Campaigns</h1>
            </div>
            <div class="item">
                <div class="top_link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#db0505" class="bi bi-arrow-right-square-fill" viewBox="0 0 16 16">
                    <path d="M0 14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2a2 2 0 0 0-2 2v12zm4.5-6.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5a.5.5 0 0 1 0-1z"/>
                    </svg> &nbsp;<a href="<?php echo e(url('campaign/create')); ?>">Start Your New Campaign Now</a>
                </div>
            </div>
        </div>


        <div class="box_body" style="min-height:680px">
            <nav class="navigation_layout_tabs" style="margin: 0px 0px 1.5rem;"><a class="navigation__link navigation__link_active" style="cursor: pointer;">All<span class="bracket" style="margin-left: 0.2rem;">(0)</span></a><a class="navigation__link " style="cursor: pointer;">Sent<span class="bracket" style="margin-left: 0.2rem;">(0)</span></a><a class="navigation__link " style="cursor: pointer;">Drafts<span class="bracket" style="margin-left: 0.2rem;">(0)</span></a><a class="navigation__link " style="cursor: pointer;">Scheduled<span class="bracket" style="margin-left: 0.2rem;">(0)</span></a><a class="navigation__link " style="cursor: pointer;">Suspended<span class="bracket" style="margin-left: 0.2rem;">(0)</span></a><a class="navigation__link " style="cursor: pointer;">Running<span class="bracket" style="margin-left: 0.2rem;">(0)</span></a><a class="navigation__link " style="cursor: pointer;">Archived<span class="bracket" style="margin-left: 0.2rem;">(0)</span></a></nav>
            <div class="campaignListing__templateSearchBox___LgSif">
                <div class="templateSearch__box___24T3f">
                    <div class="searchEntry__field___1MLOZ entry__field">
                        <input type="search" class="input" placeholder="Campaign ID, Name" value="">
                        <button type="submit" class="input__affix input__button">
                            <svg viewBox="0 0 24 24" class="icon clickable__icon icon_standalone"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path><path fill="none" d="M0 0h24v24H0z"></path></svg>
                        </button>
                    </div>
                </div>
            </div>
            <h4 class="center">No records found</h4>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\beta_laravel\resources\views/campagin/index.blade.php ENDPATH**/ ?>