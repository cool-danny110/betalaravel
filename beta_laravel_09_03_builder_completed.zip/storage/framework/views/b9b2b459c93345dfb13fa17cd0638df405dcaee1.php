<title>ACCOUNT : Contacts</title>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="sub-header">
        Contacts
    </div>
    <div class="content-tool mt-3 mb-4">
        <a href="<?php echo e(url('contact/import')); ?>">
            <button class="btn-form-primary me-4">
                Import Contact
            </button>
        </a>
        <a href="<?php echo e(url('contact/create')); ?>">
            <button class="btn-form-danger text-white">
                + Add Contact
            </button>
        </a>
    </div>
    <?php if( session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show mt-4" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="contact-content mt-2">
        <table id="contactTable" class="table table-bordered" width='100%' border="1" style='border-collapse: collapse;'>
            <thead>
                <tr>
                    <th>No</th>
                    <th>E-mail</th>
                    <th>LAST NAME</th>
                    <th>FIRST NAME</th>
                    <th>SMS</th>
                    <th>WHATSAPP</th>
                    <th>DOUBLE_OPT-IN</th>
                    <th>OPT_IN</th>
                    <th>Last changed</th>
                    <th>Created At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($data) && $data->count()): ?>
                    <?php $index = 1; ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(((isset($_GET['page']) ? $_GET['page'] : 1)  - 1) * env('itemsperpage') + $index); ?></td>
                            <td><?php echo e($value->email); ?></td>
                            <td><?php echo e($value->lastname); ?></td>
                            <td><?php echo e($value->firstname); ?></td>
                            <td><?php echo e($value->sms); ?></td>
                            <td><?php echo e($value->whatsapp); ?></td>
                            <td><?php echo e($value->double_opt_in); ?></td>
                            <td><?php echo e($value->opt_in); ?></td>
                            <td><?php echo e($value->updated_at); ?></td>
                            <td><?php echo e($value->created_at); ?></td>
                            <td>
                                <div class="d-flex">
                                    <a href="<?php echo e(url('contact/edit/'. $value->id)); ?>"><button class="btn-form-classic me-2">Edit</button></a>
                                    <button class="btn-form-classic" onclick="show(this)">Delete</button>
                                </div>
                                <form method="post" action="<?php echo e(route('contact.delete')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input name="id" value="<?php echo e($value->id); ?>" hidden/>
                                    <div class="confirm-delete mt-2" style="display:none">
                                        <button type="submit" class="btn-form-danger text-white me-2">Yes</button>
                                        <button type="button" class="btn-form-primary" onclick="cancel(this)">Cancel</button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    <?php $index++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="10">There are no data.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    
    $(document).ready(function(){

        // DataTable
        $('#contactTable').DataTable({
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, 'All'],
            ],
            columns: [
                { orderable: true },
                { orderable: false },
                { orderable: false },
                { orderable: false },
                { orderable: false },
                { orderable: false },
                { orderable: false },
                { orderable: false },
                { orderable: true },
                { orderable: true },
                { orderable: false },
            ]
        });

    });

    function cancel(obj) {
        $(obj).parent().css('display', 'none');
    }

    function show(obj) {
        $('.confirm-delete').css('display', 'none');
        console.log($(obj).parent().parent().find('.confirm-delete')[0].style.display);
        $(obj).parent().parent().find('.confirm-delete')[0].style.display = "flex";
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\beta_laravel\resources\views/contacts/index.blade.php ENDPATH**/ ?>