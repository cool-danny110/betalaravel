<title>ACCOUNT : IMPORT CONTACT</title>
<?php $__env->startSection('content'); ?>
<div class="content contact-form">
  <form method="post" action="<?php echo e(route('contact.upload')); ?>">
    <?php echo csrf_field(); ?>
    <div class="sub-header">
        Import Contact
    </div>
    <div class="content-tool mt-3 mb-4">
        <a href="<?php echo e(url('contact')); ?>">
            <button type="button" class="btn-form-danger text-white me-4">
                <i class="fa fa-arrow-left"></i>Back To Contact List
            </button>
        </a>
        <button type="submit" class="btn-form-primary text-white">
            + Upload
        </button>
    </div>
    <input name="filename" value="<?php echo e($filename); ?>" hidden/>
    <div class="alert alert-success alert-dismissible fade show mt-4" role="alert">
        Please confirm the contact list that you imported and upload it.
    </div>
    <div class="contact-content mt-2">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>E-mail</th>
                    <th>LAST NAME</th>
                    <th>FIRST NAME</th>
                    <th>SMS</th>
                    <th>WHATSAPP</th>
                    <th>DOUBLE_OPT-IN</th>
                    <th>OPT_IN</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($data) && count($data)!= 0): ?>
                    <?php $index = 1; ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($value[0] != ''): ?>
                        <tr>
                            <td><?php echo e($value[0]); ?></td>
                            <td><?php echo e(isset($value[1]) ? $value[1] : ''); ?></td>
                            <td><?php echo e(isset($value[2]) ? $value[2] : ''); ?></td>
                            <td><?php echo e(isset($value[3]) ? $value[3] : ''); ?></td>
                            <td><?php echo e(isset($value[4]) ? $value[4] : ''); ?></td>
                            <td><?php echo e(isset($value[5]) ? $value[5] : ''); ?></td>
                            <td><?php echo e(isset($value[6]) ? $value[6] : ''); ?></td>
                        </tr>
                      <?php endif; ?>
                    <?php $index++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="10">There are no data.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="content-tool mt-3 mb-4">
          <button type="submit" class="btn-form-primary text-white">
              + Upload
          </button>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\beta_laravel\resources\views/contacts/import-process.blade.php ENDPATH**/ ?>