<title>ACCOUNT : IMPORT CONTACT</title>
<?php $__env->startSection('content'); ?>
<div class="content contact-form">
    <div class="sub-header">
        Import Contact
    </div>
    <div class="content-tool mt-3 mb-4">
        <a href="<?php echo e(url('contact')); ?>">
            <button class="btn-form-danger text-white">
                <i class="fa fa-arrow-left"></i>Back To Contact List
            </button>
        </a>
    </div>
    <div class="contact-template ms-4 mt-3 mb-4">
      <div><a href="<?php echo e(asset('public/assets/templates/contact/samplecontact.csv')); ?>" download><i class="fa fa-file-excel"></i><span class="ms-2">XLS contact template download</span></a></div>
      <div><a href="<?php echo e(asset('public/assets/templates/contact/samplecontact.csv')); ?>" download><i class="fa fa-file-csv"></i><span class="ms-2">CSV contact template download</span></a></div>
      <div><a href="<?php echo e(asset('public/assets/templates/contact/samplecontact.txt')); ?>" download><i class="fa fa-file-text"></i><span class="ms-2">TXT contact template download</span></a></div>

    </div>
    <form id="import_form" method="post" action="<?php echo e(route('contact.fileimport')); ?>" enctype="multipart/form-data" >
      <?php echo csrf_field(); ?>
      <div class="file-upload mt-4 px-2">
        <div class="file-upload-select">
          <div class="file-select-button" >Choose File</div>
          <div class="file-select-name">No file chosen...</div> 
          <input type="file" name="file" id="file-upload-input" accept=".csv, .txt">
        </div>
      </div>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
  let fileInput = document.getElementById("file-upload-input");
  let fileSelect = document.getElementsByClassName("file-upload-select")[0];
  fileSelect.onclick = function() {
    fileInput.click();
  }
  fileInput.onchange = function() {
    let filename = fileInput.files[0].name;
    let selectName = document.getElementsByClassName("file-select-name")[0];
    selectName.innerText = filename;
    $("#import_form").submit();
  }

  
    
  // fileInput.onchange = function() {
  //   $("#import_form").submit();
  //   // let filename = fileInput.files[0].name;
  //   // let selectName = document.getElementsByClassName("file-select-name")[0];
  //   // selectName.innerText = filename;
  // }


  // function importFile() {
  //   $("#import_form").submit();
  // }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\beta_laravel\resources\views/contacts/import.blade.php ENDPATH**/ ?>