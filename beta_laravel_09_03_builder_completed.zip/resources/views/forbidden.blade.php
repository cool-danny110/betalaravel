@extends('layouts.app')
<title>ACCOUNT : Contacts</title>
@section('content')
<div class="content">
    Unfortunately, you are forbidden to access to this page.
</div>
@endsection
